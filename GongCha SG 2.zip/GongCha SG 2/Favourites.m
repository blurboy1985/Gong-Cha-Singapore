//
//  Favourites.m
//  GongChaSG
//
//  Created by Daniel Quek on 26/8/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Favourites.h"


@implementation Favourites
@dynamic ice;
@dynamic name;
@dynamic pearl;
@dynamic sugar;
@dynamic quantity;

@end
