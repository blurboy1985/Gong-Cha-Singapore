//
//  DrinkObject.h
//  GongChaSG
//
//  Created by Daniel Quek on 27/11/11.
//  Copyright (c) 2011 Cellcity. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DrinkObject : NSObject

@property (nonatomic,retain) NSArray *hotDrinksAvailable;
@property (nonatomic,retain) NSArray *hotDrinksOnly;

@end
